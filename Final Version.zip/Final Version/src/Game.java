/**
 * @author Tyler Wengrzyn
 * 
 * @version 4/29/2016
 * 
 * Final version of dice game with GUI for CSE 360 Team 2*/

import java.awt.Color;
import java.util.Random;
import java.util.*;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Object;
import java.io.*;

public class Game extends JApplet
{
	private JButton vsComp, vsPlayer, stats, quit, start, roll, replay, menu, ok, create, delete, 
					createORdelete, createConf, deleteConf, search, back;
	private JPanel layout, buttonSizer, buttonLayout, titleLayout, titleImage, 
					player1Layout, player2Layout, diceRoll, die1, die2, die3, listSizer, listLayout;
	private int p1Score, p2Score, die1Roll, die2Roll, die3Roll, p1Penalty, p2Penalty, p1Index, p2Index;
	private boolean p1Turn, compGame, createPrev;
	private Vector<player> playerVector = new Vector();
	private Vector<String> playerNames = new Vector();
	private ImageIcon imageIcon;
	private JList<String> playerList, player1List, player2List;
	private JRadioButton diceOption1, diceOption2, diceOption3;
	private JLabel title, names, player1Stats, player2Stats , player1Logo, player2Logo, playerStats;
	private JFrame mainFrame;
	private Random rand;
	private JTextField newPlayer;
	
	private class player
	{
		String name;
		int gamesPlayed;
		int gamesWon;
		int gamesLost;
		int lowestRolls;
		int highestRolls;
	}
	
	/**This is basically to provide commands for the buttons*/
	ActionListener actionListener = new ActionListener() 
	{
        public void actionPerformed(ActionEvent actionEvent) 
        {
          if(actionEvent.getActionCommand() == "vsComp")
          {
        	  p1Score = 100;
        	  p2Score = 100;
        	  compGame = true;
        	  
             	playerList = new JList(playerNames);
             	playerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
             	playerList.setLayoutOrientation(JList.VERTICAL);
             	playerList.setVisibleRowCount(5);
             	JScrollPane listScroller = new JScrollPane(playerList);
             	listScroller.setPreferredSize(new Dimension(250, 80));
        	  
        	    listSizer = new JPanel();
             	listSizer.setBackground(Color.black);
             	listLayout = new JPanel();
             	listLayout.setBackground(Color.black);
             	listLayout.setLayout(new GridLayout(1, 2, 0, 50));
             	listLayout.add(playerList);
             	listSizer.add(listLayout);
        	  
        	  mainFrame.getContentPane().removeAll();
        	  playerSelect();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "vsPlayer")
          {
        	  p1Score = 100;
        	  p2Score = 100;
        	  compGame = false;
        	  
        	  player1List = new JList(playerNames);
           	player1List.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
           	player1List.setLayoutOrientation(JList.VERTICAL);
           	player1List.setVisibleRowCount(5);
           	JScrollPane listScroller1 = new JScrollPane(player1List);
           	listScroller1.setPreferredSize(new Dimension(250, 80));
           	
           	player2List = new JList(playerNames);
           	player2List.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
           	player2List.setLayoutOrientation(JList.VERTICAL);
           	player2List.setVisibleRowCount(5);
           	JScrollPane listScroller2 = new JScrollPane(player2List);
           	listScroller2.setPreferredSize(new Dimension(250, 80));
        	  
        	  listSizer = new JPanel();
           	  listSizer.setBackground(Color.black);
           	  listLayout = new JPanel();
           	  listLayout.setBackground(Color.black);
           	  listLayout.setLayout(new GridLayout(1, 2, 50, 50));
           	  listLayout.add(player1List);
           	  listLayout.add(player2List);
           	  listSizer.add(listLayout);
        	  
        	  mainFrame.getContentPane().removeAll();
        	  playerSelect();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "stats")
          {
        	  playerList = new JList(playerNames);
           	  playerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
           	  playerList.setLayoutOrientation(JList.VERTICAL);
           	  playerList.setVisibleRowCount(5);
           	  playerStats = new JLabel();
           	  JScrollPane listScroller = new JScrollPane(playerList);
           	  listScroller.setPreferredSize(new Dimension(250, 80));
           	playerStats = new JLabel("<html>*Games Played: "
           			+ "<br>*Games Won:  " 
        	  		+ "<br>*Games Lost:  "
        	  		+ "<br>*Lowest Roll: "
        	  		+ "<br>*Highest Roll: </html>", JLabel.LEFT); //Separate with <br>
           	playerStats.setFont(new Font("TimesRoman", Font.PLAIN, 25));
           	playerStats.setForeground(Color.black);
           	listSizer = new JPanel();
         	listSizer.setBackground(Color.blue);
         	listLayout = new JPanel();
         	listLayout.setBackground(Color.blue);
         	listLayout.setLayout(new GridLayout(1, 2, 0, 50));
         	listLayout.add(playerList);
         	listSizer.add(listLayout);
        	  mainFrame.getContentPane().removeAll();
        	  statScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "quit")
          {
        	  //saveList(playerVector);
              //saveNames(playerNames);
        	  System.exit(0);
          }
          else if(actionEvent.getActionCommand() == "menu")
          {
        	  mainFrame.getContentPane().removeAll();
        	  titleScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "start")
          {
        	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
             title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
             title.setForeground(Color.red);
             p1Turn = true;
        	  die1 = new JPanel();
        	  die1.setBackground(Color.orange);
        	  die2 = new JPanel();
        	  die2.setBackground(Color.orange);
        	  die3 = new JPanel();
        	  die3.setBackground(Color.orange);
        	  die1.add(die(1));
        	  die2.add(die(2));
        	  die3.add(die(3));
        	  mainFrame.getContentPane().removeAll();
        	  gameScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "roll")
          {
        	  rand = new Random();
        	  if(p1Turn == true && compGame == true)
        	  {
        		  if(diceOption1.isSelected() == true)
        		  {
        			  if(p1Penalty > 0)
        			  {
        				  p1Penalty--;
        			  }
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die1Roll = 0;
        			  die3Roll = 0;
        			  if((p1Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p1Score = p1Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p1Index).highestRolls)
        				  {
        					  playerVector.get(p1Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p1Index).lowestRolls)
        				  {
        					  playerVector.get(p1Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel("Computer's Turn", JLabel.CENTER);
                     title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                     p1Turn = false;
                     title.setForeground(Color.gray);
                     
        		  }
        		  else if(diceOption2.isSelected() == true && p1Penalty == 0)
        		  {
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die3Roll = 0;
        			  if((p1Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p1Score = p1Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p1Index).highestRolls)
        				  {
        					  playerVector.get(p1Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p1Index).lowestRolls)
        				  {
        					  playerVector.get(p1Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel("Computer's Turn", JLabel.CENTER);
                     title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                     p1Turn = false;
                     title.setForeground(Color.gray);
        		  }
        		  else if(diceOption3.isSelected() == true && p1Penalty == 0)
        		  {
        			  p1Penalty = 3;
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die3Roll = rand.nextInt(6);
        			  die3Roll++;
        			  if((p1Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p1Score = p1Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p1Index).highestRolls)
        				  {
        					  playerVector.get(p1Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p1Index).lowestRolls)
        				  {
        					  playerVector.get(p1Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel("Computer's Turn", JLabel.CENTER);
                     title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                     p1Turn = false;
                     title.setForeground(Color.gray);
        		  }
        	  }
        	  else if(p1Turn == false && compGame == true)
        	  {
        		  if(diceOption1.isSelected() == true)
        		  {
        			  if(p2Penalty > 0)
        			  {
        				  p2Penalty--;
        			  }
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die1Roll = 0;
        			  die3Roll = 0;
        			  if((p2Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p2Score = p2Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p2Index).highestRolls)
        				  {
        					  playerVector.get(p2Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p2Index).lowestRolls)
        				  {
        					  playerVector.get(p2Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
                      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                      p1Turn = true;
                      title.setForeground(Color.red);
                      mainFrame.getContentPane().removeAll();
      	  			gameScreen();
      	  			((JPanel)mainFrame.getContentPane()).revalidate();
            			mainFrame.repaint();
        		  }
        		  else if(diceOption2.isSelected() == true && p2Penalty == 0)
        		  {
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die3Roll = rand.nextInt(6);
        			  die3Roll++;
        			  die2Roll = 0;
        			  if((p2Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p2Score = p2Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p2Index).highestRolls)
        				  {
        					  playerVector.get(p2Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p2Index).lowestRolls)
        				  {
        					  playerVector.get(p2Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
                      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                      p1Turn = true;
                      title.setForeground(Color.red);
        		  }
        		  else if(diceOption3.isSelected() == true && p2Penalty == 0)
        		  {
        			  p2Penalty = 3;
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die3Roll = rand.nextInt(6);
        			  die3Roll++;
        			  if((p2Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p2Score = p2Score - die1Roll - die2Roll - die3Roll;
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
                     title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                     p1Turn = true;
                     title.setForeground(Color.red);
        		  }
              }
        	  else if(p1Turn == true && compGame == false)
        	  {
        		  if(diceOption1.isSelected() == true)
        		  {
        			  if(p1Penalty > 0)
        			  {
        				  p1Penalty--;
        			  }
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die1Roll = 0;
        			  die3Roll = 0;
        			  if((p1Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p1Score = p1Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p1Index).highestRolls)
        				  {
        					  playerVector.get(p1Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p1Index).lowestRolls)
        				  {
        					  playerVector.get(p1Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p2Index).name + "'s Turn", JLabel.CENTER);
                      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                      p1Turn = false;
                      title.setForeground(Color.blue);
        		  }
        		  else if(diceOption2.isSelected() == true && p1Penalty == 0)
        		  {
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die3Roll = rand.nextInt(6);
        			  die3Roll++;
        			  die2Roll = 0;
        			  if((p1Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p1Score = p1Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p1Index).highestRolls)
        				  {
        					  playerVector.get(p1Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p1Index).lowestRolls)
        				  {
        					  playerVector.get(p1Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p2Index).name + "'s Turn", JLabel.CENTER);
                      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                      p1Turn = false;
                      title.setForeground(Color.blue);
        		  }
        		  else if(diceOption3.isSelected() == true && p1Penalty == 0)
        		  {
        			  p1Penalty = 3;
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die3Roll = rand.nextInt(6);
        			  die3Roll++;
        			  if((p1Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p1Score = p1Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p1Index).highestRolls)
        				  {
        					  playerVector.get(p1Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p1Index).lowestRolls)
        				  {
        					  playerVector.get(p1Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p2Index).name + "'s Turn", JLabel.CENTER);
                     title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                     p1Turn = false;
                     title.setForeground(Color.blue);
        		  }
        	  }
        	  else if(p1Turn == false && compGame == false)
        	  {
        		  if(diceOption1.isSelected() == true)
        		  {
        			  if(p2Penalty > 0)
        			  {
        				  p2Penalty--;
        			  }
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die1Roll = 0;
        			  die3Roll = 0;
        			  if((p2Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p2Score = p2Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p2Index).highestRolls)
        				  {
        					  playerVector.get(p2Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p2Index).lowestRolls)
        				  {
        					  playerVector.get(p2Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
                      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                      p1Turn = true;
                      title.setForeground(Color.red);
        		  }
        		  else if(diceOption2.isSelected() == true && p2Penalty == 0)
        		  {
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die3Roll = rand.nextInt(6);
        			  die3Roll++;
        			  die2Roll = 0;
        			  if((p2Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p2Score = p2Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p2Index).highestRolls)
        				  {
        					  playerVector.get(p2Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p2Index).lowestRolls)
        				  {
        					  playerVector.get(p2Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
                      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                      p1Turn = true;
                      title.setForeground(Color.red);
        		  }
        		  else if(diceOption3.isSelected() == true && p2Penalty == 0)
        		  {
        			  p2Penalty = 3;
        			  die1Roll = rand.nextInt(6);
        			  die1Roll++;
        			  die2Roll = rand.nextInt(6);
        			  die2Roll++;
        			  die3Roll = rand.nextInt(6);
        			  die3Roll++;
        			  if((p2Score - die1Roll - die2Roll - die3Roll) >= 0)
        			  {
        				  p2Score = p2Score - die1Roll - die2Roll - die3Roll;
        				  if((die1Roll + die2Roll + die3Roll) > playerVector.get(p2Index).highestRolls)
        				  {
        					  playerVector.get(p2Index).highestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        				  else if((die1Roll + die2Roll + die3Roll) < playerVector.get(p2Index).lowestRolls)
        				  {
        					  playerVector.get(p2Index).lowestRolls = (die1Roll + die2Roll + die3Roll); 
        				  }
        			  }
        			  die1 = new JPanel();
                	  die1.setBackground(Color.orange);
                	  die2 = new JPanel();
                	  die2.setBackground(Color.orange);
                	  die3 = new JPanel();
                	  die3.setBackground(Color.orange);
                	  die1.add(die(die1Roll));
                	  die2.add(die(die2Roll));
                	  die3.add(die(die3Roll));
                	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
                     title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
                     p1Turn = true;
                     title.setForeground(Color.red);
        		  }
        	  }
        	  if(p1Score == 0)
        	  {
        		  title = new JLabel(playerVector.get(p1Index).name + " Wins!", JLabel.CENTER);
        	      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
        	      title.setForeground(Color.red);
        	      playerVector.get(p1Index).gamesWon++;
    		      playerVector.get(p2Index).gamesLost++;
    		      playerVector.get(p1Index).gamesPlayed++;
    		      playerVector.get(p2Index).gamesPlayed++;
        	      mainFrame.getContentPane().removeAll();
            	  winScreen();
            	  ((JPanel)mainFrame.getContentPane()).revalidate();
                  mainFrame.repaint();
        	  }
        	  else if(p2Score == 0)
        	  {
        		  if(compGame == true)
        		  {
        			  title = new JLabel("Computer Wins!", JLabel.CENTER);
        		      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
        		      title.setForeground(Color.gray);
        		      playerVector.get(p1Index).gamesLost++;
        		      playerVector.get(p1Index).gamesPlayed++;
        		  }
        		  else
        		  {
        			  title = new JLabel(playerVector.get(p2Index).name + " Wins!", JLabel.CENTER);
        		      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
        		      title.setForeground(Color.blue);
        		      playerVector.get(p2Index).gamesWon++;
        		      playerVector.get(p1Index).gamesLost++;
        		      playerVector.get(p1Index).gamesPlayed++;
        		      playerVector.get(p2Index).gamesPlayed++;
        		  }
        		mainFrame.getContentPane().removeAll();
          	  	winScreen();
          	  	((JPanel)mainFrame.getContentPane()).revalidate();
                mainFrame.repaint();
        	  }
        	  else
        	  {
        		mainFrame.getContentPane().removeAll();
        	  	gameScreen();
        	  	((JPanel)mainFrame.getContentPane()).revalidate();
              	mainFrame.repaint();
              	if(p1Turn == false && compGame == true)
              	{
          			//sleep(3000);
              		if(p2Penalty > 0 || p2Score <= 6)
          			{
          				diceOption1.setSelected(true);
          				diceOption2.setSelected(false);
          				diceOption3.setSelected(false);
          			}
          			else if(p2Penalty == 0 && p2Score <= 12 && p2Score >= 7)
          			{
          				diceOption1.setSelected(false);
          				diceOption2.setSelected(true);
          				diceOption3.setSelected(false);
          			}
          			else if(p2Penalty == 0 && p2Score > 12)
          			{
          				diceOption1.setSelected(false);
          				diceOption2.setSelected(false);
          				diceOption3.setSelected(true);
          			}
              		roll.doClick();
          	  }
        	  }
          }
          else if(actionEvent.getActionCommand() == "replay")
          {
        	  title = new JLabel(playerVector.get(p1Index).name + "'s Turn", JLabel.CENTER);
              title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
              title.setForeground(Color.red);
              p1Turn = true;
              p1Score = 100;
              p2Score = 100;
         	  die1 = new JPanel();
         	  die1.setBackground(Color.orange);
         	  die2 = new JPanel();
         	  die2.setBackground(Color.orange);
         	  die3 = new JPanel();
         	  die3.setBackground(Color.orange);
         	  die1.add(die(1));
         	  die2.add(die(2));
         	  die3.add(die(3));
        	  mainFrame.getContentPane().removeAll();
        	  gameScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "ok")
          {
        	  if(playerNames.isEmpty() == false)
        	  {
        		  if(compGame == false)
        	  	{
        		  if(player1List.getSelectedIndex() != player2List.getSelectedIndex())
         	 		{
        			  p1Index = player1List.getSelectedIndex();
        			  p2Index = player2List.getSelectedIndex();
        			  playerVector.get(p1Index).lowestRolls = 18;
        			  playerVector.get(p2Index).lowestRolls = 18;
        			  mainFrame.getContentPane().removeAll();
        			  ruleScreen();
        			  ((JPanel)mainFrame.getContentPane()).revalidate();
        			  mainFrame.repaint();
         	 		}
        	  	}
        	  	else
        	  	{
        	  		p1Index = playerList.getSelectedIndex();
        	  		playerVector.get(p1Index).lowestRolls = 18;
        	  		mainFrame.getContentPane().removeAll();
    			  	ruleScreen();
    			  	((JPanel)mainFrame.getContentPane()).revalidate();
    			  	mainFrame.repaint();
        	  	}
        	  }
          }
          else if(actionEvent.getActionCommand() == "create/delete")
          {
        		mainFrame.getContentPane().removeAll();
               	createORdelete();
               	((JPanel)mainFrame.getContentPane()).revalidate();
                mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "create")
          {
        	  newPlayer = new JTextField(20);
        	  mainFrame.getContentPane().removeAll();
             createPlayer();
             ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "delete")
          {	
           	playerList = new JList(playerNames);
         	playerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         	playerList.setLayoutOrientation(JList.VERTICAL);
         	playerList.setVisibleRowCount(5);
         	JScrollPane listScroller = new JScrollPane(playerList);
         	listScroller.setPreferredSize(new Dimension(250, 80));
         	listSizer = new JPanel();
         	listSizer.setBackground(Color.black);
         	listLayout = new JPanel();
         	listLayout.setBackground(Color.black);
         	listLayout.setLayout(new GridLayout(1, 2, 0, 50));
         	listLayout.add(playerList);
         	listSizer.add(listLayout);
           	mainFrame.getContentPane().removeAll();
           	deletePlayer();
           	((JPanel)mainFrame.getContentPane()).revalidate();
            mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "createConf")
          {
        	  if(newPlayer.getText() != null)
        	  {
        		  boolean playerExists = false;
        		  for(int index = 0; index < playerNames.size(); index++)
        		  {
        			  if(playerNames.get(index).equals(newPlayer.getText()))
        			  {
        				  playerExists = true;
        			  }
        		  }
        		  if(playerExists == true)
        		  {
        			  title = new JLabel("Player Already Exists", JLabel.CENTER);
        		      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
        		      title.setForeground(Color.white);
        		      mainFrame.getContentPane().removeAll();
        	          errorScreen();
        	          ((JPanel)mainFrame.getContentPane()).revalidate();
        	          mainFrame.repaint();
        		  }
        		  else
        		  {
        			  player temp = new player();
        			  temp.name = newPlayer.getText();
        			  playerVector.addElement(temp);
        			  playerNames.addElement(newPlayer.getText());
        			  title = new JLabel("Player Created", JLabel.CENTER);
        		      title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
        		      title.setForeground(Color.white);
        		      mainFrame.getContentPane().removeAll();
        	          confirmScreen();
        	          ((JPanel)mainFrame.getContentPane()).revalidate();
        	          mainFrame.repaint();
        		  }
        	  }
          }
          else if(actionEvent.getActionCommand() == "deleteConf")
          {
        	  if(playerVector.isEmpty() == false)
        	  {
        		playerVector.remove(playerList.getSelectedIndex());
        	  	playerNames.remove(playerList.getSelectedIndex());
        	  	title = new JLabel("Player Deleted", JLabel.CENTER);
		      	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
		      	title.setForeground(Color.white);
		      	mainFrame.getContentPane().removeAll();
	          	confirmScreen();
	          	((JPanel)mainFrame.getContentPane()).revalidate();
	          	mainFrame.repaint();
        	  }
        	  else
        	  {
        		title = new JLabel("No Players Exist", JLabel.CENTER);
  		      	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
  		      	title.setForeground(Color.white);
  		      	mainFrame.getContentPane().removeAll();
  	          	errorScreen();
  	          	((JPanel)mainFrame.getContentPane()).revalidate();
  	          	mainFrame.repaint();
        	  }
          }
          else if(actionEvent.getActionCommand() == "search")
          {
        	  playerStats = new JLabel("<html>*Games Played: " + playerVector.get(playerList.getSelectedIndex()).gamesPlayed
        	  		+ "<br>*Games Won:  " + playerVector.get(playerList.getSelectedIndex()).gamesWon
        	  		+ "<br>*Games Lost:  " + playerVector.get(playerList.getSelectedIndex()).gamesLost
        	  		+ "<br>*Lowest Roll: " + playerVector.get(playerList.getSelectedIndex()).lowestRolls
        	  		+ "<br>*Highest Roll: " + playerVector.get(playerList.getSelectedIndex()).highestRolls + "</html>", JLabel.LEFT); //Separate with <br>
        	  playerStats.setFont(new Font("TimesRoman", Font.PLAIN, 25));
             	playerStats.setForeground(Color.black);
        	  mainFrame.getContentPane().removeAll();
             statScreen();
             ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "back")
          {
        	  if(createPrev == true)
        	  {
        		  mainFrame.getContentPane().removeAll();
        		  createPlayer();
        		  ((JPanel)mainFrame.getContentPane()).revalidate();
        		  mainFrame.repaint();
        	  }
        	  else
        	  {
        		  mainFrame.getContentPane().removeAll();
        		  deletePlayer();
        		  ((JPanel)mainFrame.getContentPane()).revalidate();
        		  mainFrame.repaint();
        	  }
          }
        }
	};
	
	/**
	 * Load player data from file.
	 * 
	 * @return List of players and their associated data
	 */
	public Vector<player> loadList()
	{
		Vector<player> load = null;
		
		File file = new File("playerVector.ser");
		if (file.exists())
		{
			try
		      {
		         FileInputStream fileIn = new FileInputStream(file);
		         ObjectInputStream in = new ObjectInputStream(fileIn);
		         load = (Vector<player>)in.readObject();
		         in.close();
		         fileIn.close();
		      }catch(IOException i)
		      {
		         i.printStackTrace();
		         //return;
		      }catch(ClassNotFoundException c)
		      {
		         System.out.println("Save data not found");
		         c.printStackTrace();
		         //return;
		      }
		}
		else
		{
			load = playerVector;
		}
		
		return load;
	}
	
	/**
	 * Save player data to file
	 * 
	 * @param list List of players to be saved
	 */
	public void saveList(Vector<player> playerVector)
	{
		try
	      {
	         FileOutputStream fileOut = new FileOutputStream("playerVector.ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(playerVector);
	         out.close();
	         fileOut.close();
	      }catch(IOException i)
	      {
	          i.printStackTrace();
	      }
	}
	
	/**
	 * Load player data from file.
	 * 
	 * @return List of player names
	 */
	public Vector<String> loadNames()
	{
		Vector<String> load = null;
		
		File file = new File("playerNames.ser");
		if (file.exists())
		{
			try
		      {
		         FileInputStream fileIn = new FileInputStream(file);
		         ObjectInputStream in = new ObjectInputStream(fileIn);
		         load = (Vector<String>)in.readObject();
		         in.close();
		         fileIn.close();
		      }catch(IOException i)
		      {
		         i.printStackTrace();
		         //return;
		      }catch(ClassNotFoundException c)
		      {
		         System.out.println("Save data not found");
		         c.printStackTrace();
		         //return;
		      }
		}
		else
		{
			load = playerNames;
		}
		
		return load;
	}
	
	/**
	 * Save player names to file
	 * 
	 * @param list List of player names to be saved
	 */
	public void saveNames(Vector<String> playerNames)
	{
		try
	      {
	         FileOutputStream fileOut = new FileOutputStream("playerNames.ser");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(playerNames);
	         out.close();
	         fileOut.close();
	      }catch(IOException i)
	      {
	          i.printStackTrace();
	      }
	}
	
	/**Intended as die object
	 * @param dieValue is supposed to be the value rolled on the die*/
	public JLabel die(int dieValue)
	{
		JLabel label = new JLabel();
		if(dieValue == 1)
		{
			ImageIcon dieFace = new ImageIcon("DieFace1.jpg");
			label = new JLabel(dieFace);
		}
		else if(dieValue == 2)
		{
			ImageIcon dieFace = new ImageIcon("DieFace2.jpg");
			label = new JLabel(dieFace);
		}
		else if(dieValue == 3)
		{
			ImageIcon dieFace = new ImageIcon("DieFace3.jpg");
			label = new JLabel(dieFace);
		}
		else if(dieValue == 4)
		{
			ImageIcon dieFace = new ImageIcon("DieFace4.jpg");
			label = new JLabel(dieFace);
		}
		else if(dieValue == 5)
		{
			ImageIcon dieFace = new ImageIcon("DieFace5.jpg");
			label = new JLabel(dieFace);
		}
		else if(dieValue == 6)
		{
			ImageIcon dieFace = new ImageIcon("DieFace6.jpg");
	       	label = new JLabel(dieFace);
		}
		return label;
	}
	/**Provides display for title screen*/
	public void titleScreen()
	{	
		layout = new JPanel();
       	layout.setBackground(Color.red);
       	layout.setLayout(new GridLayout(3,1));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.red);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.red);
       	buttonLayout.setLayout(new GridLayout(5, 1, 12, 12));
       	
       	createORdelete = new JButton("Create/Delete Player");
       	createORdelete.setPreferredSize(new Dimension(150, 35));
       	vsComp = new JButton("VS. Comp");
       	vsComp.setPreferredSize(new Dimension(150, 35));
       	vsPlayer = new JButton("VS. Player");
       	vsPlayer.setPreferredSize(new Dimension(150, 35));
       	stats = new JButton("Stats");
       	stats.setPreferredSize(new Dimension(150, 35));
       	quit = new JButton("Quit");
       	quit.setPreferredSize(new Dimension(150, 35));
       	
       	createORdelete.setActionCommand("create/delete");
       	createORdelete.addActionListener(actionListener);
       	vsComp.setActionCommand("vsComp");
        vsComp.addActionListener(actionListener);
        vsPlayer.setActionCommand("vsPlayer");
        vsPlayer.addActionListener(actionListener);
        stats.setActionCommand("stats");
        stats.addActionListener(actionListener);
        quit.setActionCommand("quit");
        quit.addActionListener(actionListener);
       	
        buttonLayout.add(createORdelete);
       	buttonLayout.add(vsComp);
       	buttonLayout.add(vsPlayer);
       	buttonLayout.add(stats);
       	buttonLayout.add(quit);
       	
       	buttonSizer.add(buttonLayout);
       	
       	title = new JLabel("Working DIEtle", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 64));
       	title.setForeground(Color.black);
       	
       	names = new JLabel("Created by: Adam Charney, Francisco Goncalves de Almeida Filh, Caio Pinheiro de Carvalho, Tyler Wengrzyn, and Jacob Wiens", JLabel.CENTER);
       	names.setFont(new Font("TimesRoman", Font.PLAIN, 24));
       	names.setForeground(Color.black);
       	
       	titleLayout = new JPanel();
       	titleLayout.setLayout(new GridLayout(2, 1));
       	titleLayout.setBackground(Color.red);
       	titleLayout.add(title);
       	titleLayout.add(names);
       	
       	imageIcon = new ImageIcon("DiceGraphic.jpg");
       	JLabel label = new JLabel(imageIcon);

       	titleImage = new JPanel();
       	titleImage.add(label);
       	titleImage.setBackground(Color.red);
       	
       	layout.add(titleLayout);
       	layout.add(titleImage);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for rule screen*/
	public void ruleScreen()
	{
		layout = new JPanel();
       	layout.setBackground(Color.yellow);
       	layout.setLayout(new GridLayout(3,1));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.yellow);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.yellow);
       	buttonLayout.setLayout(new GridLayout(1, 3, 15, 15));
       	
       	start = new JButton("Start");
       	start.setActionCommand("start");
        start.addActionListener(actionListener);
        start.setPreferredSize(new Dimension(160, 80));
       	
       	menu = new JButton("Menu");
    	menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
       	
        buttonLayout.add(menu);
       	buttonLayout.add(start);
       	
       	buttonSizer.add(buttonLayout);
       	
       	title = new JLabel("Rules", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.black);
       	
       	names = new JLabel("<html>* Each player starts with 100 points."
       			+ "<br>* Each player will attempt to reach a score of 0 by rolling dice."
       			+ "<br>* You may choose to use either 1, 2, or 3 6-sided dice."
       			+ "<br>* If you choose to roll the 3 dice, then you will have to use a single die for your next 3 turns."
       			+ "<br>* If the total number you roll is greater than the amount needed to reach the target score, then it will not count."
       			+ "<br>* Each player will take turns rolling the dice by clicking the Roll button at the bottom of the screen."
       			+ "<br>* First player to reach 0 wins. </html>", JLabel.LEFT); //Separate with <br>
       	names.setFont(new Font("TimesRoman", Font.PLAIN, 24));
       	names.setForeground(Color.black);
       	
       	layout.add(title);
       	layout.add(names);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for game screen*/
	public void gameScreen()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.orange);
       	layout.setLayout(new GridLayout(4,1));
       	
       	diceRoll = new JPanel();
       	diceRoll.setBackground(Color.orange);
       	diceRoll.setLayout(new GridLayout(1, 3));
       	diceRoll.add(die1);
       	diceRoll.add(die2);
       	diceRoll.add(die3);

        roll = new JButton("Roll");
        roll.setPreferredSize(new Dimension(160, 80));
    	roll.setActionCommand("roll");
        roll.addActionListener(actionListener);
        
        buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.orange);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.orange);
       	buttonLayout.setLayout(new GridLayout(4, 1, 0, 5));
       	buttonLayout.add(roll);
       	
       	buttonSizer.add(buttonLayout);
       	
       	JPanel midLayout = new JPanel();
       	midLayout.setBackground(Color.orange);
       	midLayout.setLayout(new GridLayout(1,1));
       	
       	JPanel diceOptions = new JPanel();
       	diceOptions.setBackground(Color.orange);
       	diceOptions.setLayout(new GridLayout(3,1));
       	
       	diceOption1 = new JRadioButton("1 Die");
       	diceOption1.setBackground(Color.orange);
       	diceOption1.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	diceOption1.setForeground(Color.black);
       	diceOption1.setHorizontalAlignment(AbstractButton.CENTER);
       	
       	diceOption2 = new JRadioButton("2 Dice");
       	diceOption2.setBackground(Color.orange);
       	diceOption2.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	diceOption2.setForeground(Color.black);
       	diceOption2.setHorizontalAlignment(AbstractButton.CENTER);
       	
       	diceOption3 = new JRadioButton("3 Dice");
       	diceOption3.setBackground(Color.orange);
       	diceOption3.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	diceOption3.setForeground(Color.black);
       	diceOption3.setHorizontalAlignment(AbstractButton.CENTER);
       	
       	ButtonGroup group = new ButtonGroup();
       	group.add(diceOption1);
       	diceOption1.setSelected(true);
       	group.add(diceOption2);
       	group.add(diceOption3);
       	
       	diceOptions.add(diceOption1);
       	diceOptions.add(diceOption2);
       	diceOptions.add(diceOption3);
       	
       	player1Logo = new JLabel("<html>" + playerVector.get(p1Index).name + "</html>", JLabel.LEFT); //Separate with <br>
       	player1Logo.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	player1Logo.setForeground(Color.black);
       	
       	player1Stats = new JLabel("<html>*Current Score: " + p1Score + "</html>", JLabel.LEFT); //Separate with <br>
       	player1Stats.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	player1Stats.setForeground(Color.black);
       	
       	if(compGame == true)
       	{
       	  player2Logo = new JLabel("<html>Computer </html>", JLabel.LEFT); //Separate with <br>
      	  player2Logo.setFont(new Font("TimesRoman", Font.PLAIN, 54));
      	  player2Logo.setForeground(Color.black);
      	  player2Layout = new JPanel();
      	  player2Layout.setBackground(Color.gray);
       	}
       	else
       	{
       	  player2Logo = new JLabel("<html>" + playerVector.get(p2Index).name + "</html>", JLabel.LEFT); //Separate with <br>
      	  player2Logo.setFont(new Font("TimesRoman", Font.PLAIN, 54));
      	  player2Logo.setForeground(Color.black);
      	  player2Layout = new JPanel();
      	  player2Layout.setBackground(Color.blue);
       	}
       	player2Stats = new JLabel("<html>*Current Score: " + p2Score + "</html>", JLabel.LEFT); //Separate with <br>
       	player2Stats.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	player2Stats.setForeground(Color.black);
       	
       	player1Layout = new JPanel();
       	player1Layout.setBackground(Color.red);
       	player1Layout.setLayout(new GridLayout(2,1));
       	player1Layout.add(player1Logo);
       	player1Layout.add(player1Stats);
       	
       	player2Layout.setLayout(new GridLayout(2,1));
       	player2Layout.add(player2Logo);
       	player2Layout.add(player2Stats);
       	
       	midLayout.add(player1Layout);
       	midLayout.add(diceOptions);
       	midLayout.add(player2Layout);
       	
        
        layout.add(title);
        layout.add(diceRoll);
        layout.add(midLayout);
        layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Helps provide temporary pause in game before computer turn*/
	public static void sleep(int time)
	{
		try
			{
				Thread.sleep(time);
			}
			catch (Exception e){}
	}
	/**Provides display for stat screen*/
	public void statScreen()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.blue);
       	layout.setLayout(new GridLayout(4,1));
       	
       	title = new JLabel("Stats", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.black);
       	
       	menu = new JButton("Menu");
    	menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
        
        search = new JButton("Search");
    	search.setActionCommand("search");
        search.addActionListener(actionListener);
        search.setPreferredSize(new Dimension(160, 80));
        
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.blue);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.blue);
       	buttonLayout.setLayout(new GridLayout(1, 2, 50, 50));
       	buttonLayout.add(menu);
       	buttonLayout.add(search);
       	buttonSizer.add(buttonLayout);
       	
       	layout.add(title);
       	layout.add(listSizer);
       	layout.add(playerStats);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for win screen*/
	public void winScreen()
	{
		//saveList(playerVector);
       	//saveNames(playerNames);
		
		p1Score = 100;
		p2Score = 100;
		p1Penalty = 0;
		p2Penalty = 0;
		layout = new JPanel();
       	layout.setBackground(Color.green);
       	layout.setLayout(new GridLayout(2, 1));
       	
       	replay = new JButton("Replay");
       	replay.setActionCommand("replay");
        replay.addActionListener(actionListener);
        replay.setPreferredSize(new Dimension(160, 80));
        
        menu = new JButton("Menu");
        menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
        
        quit = new JButton("Quit");
        quit.setActionCommand("quit");
        quit.addActionListener(actionListener);
        quit.setPreferredSize(new Dimension(160, 80));

        buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.green);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.green);
       	buttonLayout.setLayout(new GridLayout(3, 1, 0, 25));
       	buttonLayout.add(replay);
       	buttonLayout.add(menu);
       	buttonLayout.add(quit);
       	buttonSizer.add(buttonLayout);
        
       	layout.add(title);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for player select screen*/
	public void playerSelect()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.black);
       	layout.setLayout(new GridLayout(3,1));
       	
       	title = new JLabel("Select Player Profile", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.white);
       	
       	ok = new JButton("OK");
        ok.setActionCommand("ok");
        ok.addActionListener(actionListener);
        ok.setPreferredSize(new Dimension(160, 80));
        
        menu = new JButton("Menu");
        menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.black);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.black);
       	buttonLayout.setLayout(new GridLayout(1, 3, 15, 5));
       	buttonLayout.add(menu);
       	buttonLayout.add(ok);
       	buttonSizer.add(buttonLayout);
       	
       	layout.add(title);
       	layout.add(listSizer);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Screen to choose between creating and deleting a player*/
	public void createORdelete()
	{
		layout = new JPanel();
       	layout.setBackground(Color.black);
       	layout.setLayout(new GridLayout(2,1));
       	
       	title = new JLabel("Would You Like to Create or Delete a Player?", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.white);
       	
       	create = new JButton("Create");
        create.setActionCommand("create");
        create.addActionListener(actionListener);
        create.setPreferredSize(new Dimension(160, 80));
        
        menu = new JButton("Menu");
        menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
        
        delete = new JButton("Delete");
        delete.setActionCommand("delete");
        delete.addActionListener(actionListener);
        delete.setPreferredSize(new Dimension(160, 80));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.black);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.black);
       	buttonLayout.setLayout(new GridLayout(1, 3, 15, 5));
       	buttonLayout.add(menu);
       	buttonLayout.add(create);
       	buttonLayout.add(delete);
       	buttonSizer.add(buttonLayout);
       	
       	layout.add(title);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Screen to insert name to create player*/
	public void createPlayer()
	{
		layout = new JPanel();
       	layout.setBackground(Color.black);
       	layout.setLayout(new GridLayout(3,1));
       	
       	createPrev = true;
       	
       	title = new JLabel("Insert New Player Name", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.white);
       	
       	createConf = new JButton("Create");
        createConf.setActionCommand("createConf");
        createConf.addActionListener(actionListener);
        createConf.setPreferredSize(new Dimension(160, 80));
        
        menu = new JButton("Menu");
        menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
       	
        JPanel textFieldSizer = new JPanel();
        JPanel textFieldLayout = new JPanel();
        textFieldLayout.add(newPlayer);
        textFieldSizer.add(textFieldLayout);
        textFieldSizer.setBackground(Color.black);
        
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.black);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.black);
       	buttonLayout.setLayout(new GridLayout(1, 2, 15, 5));
       	buttonLayout.add(menu);
       	buttonLayout.add(createConf);
       	buttonSizer.add(buttonLayout);
       	
       	layout.add(title);
       	layout.add(textFieldSizer);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Screen to select player to delete*/
	public void deletePlayer()
	{
		layout = new JPanel();
       	layout.setBackground(Color.black);
       	layout.setLayout(new GridLayout(3,1));
       	createPrev = false;
       	
       	title = new JLabel("Select Player to Delete", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.white);
       	
       	deleteConf = new JButton("Delete");
        deleteConf.setActionCommand("deleteConf");
        deleteConf.addActionListener(actionListener);
        deleteConf.setPreferredSize(new Dimension(160, 80));
        
        menu = new JButton("Menu");
        menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.black);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.black);
       	buttonLayout.setLayout(new GridLayout(1, 2, 15, 5));
       	buttonLayout.add(menu);
       	buttonLayout.add(deleteConf);
       	buttonSizer.add(buttonLayout);
       	
       	layout.add(title);
       	layout.add(listSizer);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Confirmation screen for creating and deleting players*/
	public void confirmScreen()
	{
		//saveList(playerVector);
       	//saveNames(playerNames);
		
		layout = new JPanel();
       	layout.setBackground(Color.black);
       	layout.setLayout(new GridLayout(2,1));
       	
       	menu = new JButton("Menu");
        menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.black);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.black);
       	buttonLayout.setLayout(new GridLayout(1, 1, 15, 5));
       	buttonLayout.add(menu);
       	buttonSizer.add(buttonLayout);
       	
		layout.add(title);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Displays errors for create and delete*/
	public void errorScreen()
	{
		layout = new JPanel();
       	layout.setBackground(Color.black);
       	layout.setLayout(new GridLayout(2,1));
       	
       	menu = new JButton("Menu");
        menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(160, 80));
        
        back = new JButton("Back");
        back.setActionCommand("back");
        back.addActionListener(actionListener);
        back.setPreferredSize(new Dimension(160, 80));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.black);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.black);
       	buttonLayout.setLayout(new GridLayout(1, 1, 15, 5));
       	buttonLayout.add(menu);
       	buttonLayout.add(back);
       	buttonSizer.add(buttonLayout);
       	
		layout.add(title);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	
	public void init()
	{
		//loadList();
       	//loadNames();
		mainFrame = new JFrame();
       	mainFrame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
		titleScreen();
		mainFrame.setVisible(true);
	}

}